/******************************************************************************
 * This file is a part of the ... project (C).                               *                                                   *
 ******************************************************************************/

/**
 * @file hcsr04.h
 * @author Marta Szymczyk
 * @date Jan 2022
 * @brief File containing enums, structures and declarations for HC-SR04 Ultrasonic Sensor.
 * @ver 0.1
 */

void  ms_delay_ms(unsigned int d);
unsigned int getRange(void);
void  HCSR04_Init (void);
