/******************************************************************************
 * This file is a part of the ... project (C).                               *                                                   *
 ******************************************************************************/

/**
 * @file hcsr04.c
 * @author Marta Szymczyk
 * @date Jan 2022
 * @brief File containing enums, structures and declarations for HC-SR04 Ultrasonic Sensor.
 * @ver 0.1
 */

#include "hcsr04.h"    /* header with hc-sr04 declarations */
#include "frdm_bsp.h"

#include <stdbool.h>

typedef struct {
		GPIO_Type 	*gpio;        /* GPIO base pointer */
		PORT_Type 	*port;        /* PORT base pointer */
		uint32_t		clk_mask;     /* Mask for SCGC5 register */
		uint8_t  		pin;          /* Number of PIN */
		uint8_t     unused_1;
		uint8_t     unused_2;
		uint8_t     unused_3;	
} 	PinStruct_Type;

static PinStruct_Type pin_trig = {PTB, PORTB, SIM_SCGC5_PORTB_MASK, 6,0,0,0};	//PTB6 - triger (yellow)
static PinStruct_Type pin_echo = {PTB, PORTB, SIM_SCGC5_PORTB_MASK, 7,0,0,0};	//PTB7 - echo (green)

void HCSR04_Init (void){
		// trig
		SIM->SCGC5 |= pin_trig.clk_mask;              /* connect CLOCK to port */
	  pin_trig.port->PCR[pin_trig.pin] = PORT_PCR_MUX(1UL); /* set MUX to GPIO */
	  pin_trig.gpio->PDDR |= MASK(pin_trig.pin);            /* set as OUTPUT   */
	  pin_trig.gpio->PSOR |= MASK(pin_trig.pin);            /* OFF as default  */
		// echo
		SIM->SCGC5 |= pin_echo.clk_mask;              /* connect CLOCK to port */
		pin_echo.port->PCR[pin_echo.pin] = PORT_PCR_MUX(1UL); /* set MUX to GPIO */
		pin_echo.gpio->PDDR &= ~(MASK(pin_echo.pin));         /* set as INPUT  */
}
	
void ms_delay_ms(unsigned int d){ 
		for(volatile unsigned long long int i=0; i<(2222*d); i++); 
}

static void wait_10us(void){
		for(volatile unsigned int i=0; i<40; i++); 
}

unsigned int getRange(void){
		unsigned long int echo_time;
		//trig 1
		pin_trig.gpio->PSOR |= MASK(pin_trig.pin);
    wait_10us();
    //trig 0	
		pin_trig.gpio->PCOR |= MASK(pin_trig.pin);
		echo_time=0;
		// wait for 0->1
		while(!((pin_echo.gpio->PDIR) & MASK(pin_echo.pin)));
		// pulse length
		while(((pin_echo.gpio->PDIR) & MASK(pin_echo.pin)))
				echo_time++;
		return echo_time/33;
}		// [mm]

