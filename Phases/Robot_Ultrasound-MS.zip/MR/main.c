/******************************************************************************
 * This file is a part of the ... project (C).                               *                                                   *
 ******************************************************************************/

/**
 * @file main.c
 * @author Marta Szymczyk
 * @date Jan 2022
 * @brief File containing enums, structures and declarations for HC-SR04 Ultrasonic Sensor.
 * @ver 0.1
 */

#include "led.h"
#include "frdm_bsp.h"
#include "uart0.h"
#include "hcsr04.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

/** 
* @brief The main loop. 
* 
* @return NULL 
*/ 

int main (void) 
	{
		uint32_t i=0;
		char rx_buf[]={0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,\
									 0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20,0x20};
		unsigned int range=0;

									 LED_Init(); 		// initialize all LEDs 
		UART0_Init();		// UART0 init
		HCSR04_Init();	// HCSR04 init
									 
    while (true) {
        range=getRange();
        if(range>1000){
						LED_Ctrl(LED_RED, LED_ON); 
            LED_Ctrl(LED_GREEN, LED_ON);
            LED_Ctrl(LED_BLUE, LED_ON);            
        } else if(range>200){
						LED_Ctrl(LED_RED, LED_OFF); 
            LED_Ctrl(LED_GREEN, LED_ON);
            LED_Ctrl(LED_BLUE, LED_OFF); 					
        } else if(range<100) {
						LED_Ctrl(LED_RED, LED_OFF); 
            LED_Ctrl(LED_GREEN, LED_OFF);
            LED_Ctrl(LED_BLUE, LED_ON);           
        } else {
						LED_Ctrl(LED_RED, LED_ON); 
            LED_Ctrl(LED_GREEN, LED_OFF);
            LED_Ctrl(LED_BLUE, LED_OFF); 					
        }
				ms_delay_ms(100); 
				sprintf(rx_buf,"Range: %u [mm]%c",range,0xd);
				for(i=0;rx_buf[i]!=0;i++) {
						while(!(UART0->S1 & UART0_S1_TDRE_MASK));
						UART0->D = rx_buf[i];
				}
		} 
	}

